
This supplementary package contains additional robustness tests, figures, and experimental results that were developed in response to reviewer feedback and correspond to the published version in<Computational Economics>.
